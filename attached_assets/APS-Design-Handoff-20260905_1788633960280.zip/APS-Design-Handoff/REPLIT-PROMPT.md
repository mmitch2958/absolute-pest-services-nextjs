# Copy this message into the APS Replit Agent chat

Use the attached APS-Design-Handoff package to apply the owner-approved homepage design consistently across the public Absolute Pest Services website. I love the fonts, page layouts, new logo and the request form being one of the first things visitors see. Treat the approved screenshots and final source as the visual reference, rather than inventing another redesign.

First verify that this is the current Next.js app connected to mmitch2958/absolute-pest-services-nextjs. Compare the latest project with the package so newer work is preserved. If this workspace contains the older Express/Vite app or a different repository, explain the mismatch before making changes.

Keep the warm cream backgrounds, deep forest green, clean sans-serif headings, occasional italic serif accents, generous spacing, understated cards and the supplied light/dark logo. Extend the design to all public service pages, location pages, service-area pages, about/contact/request-service pages and blog pages. Keep articles and policy pages comfortable to read. Use an early request form on pages where requesting service is the primary action; do not place a large lead form above every blog article or legal page.

Preserve each page's content, URL, search metadata, structured data, geographic phone number, service selection and existing working integrations. The existing request forms must continue to save requests, send notifications, validate submissions, protect against spam and report successful conversions exactly as before. Preserve specialty and service-area form behavior. Keep real reviews and existing imagery; do not invent testimonials, guarantees, pricing or promotions.

Do not redesign admin, technician, invoice/payment or other operational workflows as part of this public website refresh. Shared branding must not break those workflows. Show the completed public-site changes in preview before publishing.

Verify the homepage, representative service and location pages, contact/request forms, service-area forms and blog pages on desktop, tablet and mobile. Check navigation, telephone links, required fields, validation errors, successful and failed submissions, spam protection, analytics and absence of horizontal overflow. Use test fixtures or an approved test destination for delivery checks. Explain anything that could not be verified. Provide a concise list of pages changed and any remaining issues. Do not publish until I approve the completed preview.
