# APS visual system

## Direction and hierarchy

Warm, calm and confident local service. Preserve the approved fonts and layout character. The homepage is the anchor reference, not a template whose entire content must be copied to every page. Adapt page-specific copy and sections while retaining the hierarchy, spacing, palette and components.

## Palette

| Role | Value | Use |
| --- | --- | --- |
| Cream | `#f7f6f0` | Main public-page background |
| Forest | `#173f35` | Primary actions and dark feature sections |
| Forest hover | `#285748` | Primary action hover |
| Ink | `#203d34` | Headings and primary text |
| Muted | `#58665e` | Supporting text |
| Sage | `#66845d` | Large italic accents; avoid small body text without checking contrast |
| Pale sage | `#eef1e7` | Form card header |
| Sage surface | `#e9eddf` | Lower call-to-action section |
| White | `#ffffff` | Cards and form fields |
| Border | `#e1e5dc` | Cards and section divisions |
| Field border | `#d7ded3` | Form controls |
| Gold | `#c6ab68` | Logo accent only |
| Focus | `#a57921` | Visible keyboard focus outline |

The attached `design-tokens.css` exposes these as `--aps-*` custom properties under `.aps-public-theme`. It is an opt-in handoff reference, not a global CSS reset. The approved source currently uses CSS Modules and explicit values; migrate incrementally without changing its appearance.

## Typography

The approved homepage uses **Arial, Helvetica, sans-serif**. The root app also imports Inter, but Inter is not the approved homepage font. Do not substitute a new Google Font.

Italic emphasis uses **Georgia, Times New Roman, serif**, weight 400. Use it sparingly on a word or phrase in a large heading.

| Element | Approved values |
| --- | --- |
| Desktop homepage H1 | `clamp(64px, 6.9vw, 102px)`, weight 600, line-height .99, tracking -5px |
| Tablet H1, 761–1050px | `clamp(46px, 5.8vw, 61px)`, tracking -2.5px |
| Mobile H1, up to 760px | 50px, line-height 1.02, tracking -2.5px |
| Narrow H1, up to 360px | 46px |
| Section H2 | `clamp(32px, 3.3vw, 47px)`, weight 500, line-height 1.12, tracking -1.8px |
| Mobile section H2 | 34px, tracking -1.4px |
| Card H3 | 19px, weight 600, tracking -.5px |
| Hero description | 16px, line-height 1.85; mobile 14px / 1.75 |
| Standard supporting copy | 13–16px, line-height 1.75–1.9 |
| Eyebrow | 9–10px, bold, tracking 1.1–1.7px |
| Form inputs | 16px, to preserve comfortable entry and avoid mobile browser zoom |

Long service names and location titles must wrap naturally. Do not force the homepage's exact line breaks onto other pages. Blog and policy body text should remain readable at 16–18px with a restrained reading width.

## Logo

Use `assets/absolute-wordmark.svg` on light backgrounds and `assets/absolute-wordmark-light.svg` on dark backgrounds. Native viewBox: 264 × 64. Preserve aspect ratio, geometry, text and colors. The logo combines the shield/A mark with the Absolute Pest Services wordmark.

Header approved rendering: 198 × 48px on small screens; 231 × 56px from the small breakpoint. Use meaningful alt text: `Absolute Pest Services`. Link the header logo to `/`. Keep the original historical assets available for existing references; avoid replacing unrelated image files.

## Layout and spacing

- Hero: max-width 1440px, two equal columns, 40px gap, 36px 40px 40px padding at desktop. Lead copy left; request form right.
- At 1050px and below: hero padding/gap 28px. At 760px and below: one column, copy followed immediately by form, 22px horizontal padding and 23px gap. At 360px and below: 15px horizontal padding.
- Standard section container: max-width 1304px, roughly 52px desktop horizontal padding, 60–86px vertical spacing. Mobile: 22px horizontal and around 50px vertical.
- Service cards: 3 columns on desktop, 2 on mobile, 1 at 360px and below. Gap 14px desktop / 11px mobile; 8px radius and thin border.
- Process section: dark forest, two columns desktop, one column mobile. Subdued light supporting text and numbered steps.
- Header remains sticky and 80px high. Desktop navigation begins at 1024px; tablet uses the mobile menu. Keep sticky call/request actions consistent with this breakpoint.
- Form anchor scroll offset: approximately 104px desktop / 94px mobile so the header does not cover the form.

## Form presentation and behavior

The homepage contains exactly one existing `ServiceRequestForm`, using the optional `variant="hero"`. The normal variant must retain existing behavior and presentation unless a page is intentionally adapted.

Hero form card: white, 12px radius, thin pale border, subtle shadow. Pale sage header reads “FREE ESTIMATE · NO OBLIGATION” and “Let’s take care of it.” Body padding 21px 25px desktop and 18px mobile. Field controls are 42px tall, 5px radius; submit control is 46px tall. Keep visible labels, required indicators, error/success states and disabled/pending feedback.

The hero variant uses a supported compact Turnstile widget. Other variants retain their normal configuration. Never create a decorative form with a fake success state, or mount duplicate forms with conflicting IDs/widgets.

## Buttons, interaction and accessibility

Forest primary button, white bold text, 5–6px radius. Approved hover uses darker/lighter forest shift and subtle upward movement. Service-card hover raises 4px with a soft shadow. Honor `prefers-reduced-motion`: no translate or animated transition. Keep visible keyboard focus and descriptive link labels. Ensure touch targets, labels, contrast and keyboard menus remain usable when extending the system.

Retain existing photographs, verified service claims and real Google reviews. Use screenshots to match the approved result; the final source wins if a prose summary omits a detail.
