# Absolute Pest Services — approved design handoff

Approved by the owner on September 5, 2026. This package captures the approved homepage and explains how to extend its visual language across public pages.

## Open first

- `DESIGN-PREVIEW.html`: offline visual reference, approved screenshots, logo and palette.
- `REPLIT-PROMPT.md`: copy into the APS Replit Agent chat after uploading this ZIP.
- `DESIGN-SYSTEM.md`: reusable visual rules and exact values.
- `ROLLOUT-AND-VERIFICATION.md`: page families, integration requirements and checks.
- `approved-source/`: the 11 final source files, with their original repository paths.
- `assets/`: the approved SVG wordmarks.
- `references/`: the approved desktop, mobile, tablet and full-page captures.
- `aps-homepage-refresh-v2.patch`: both design commits, relative to the original base.
- `design-tokens.css`: opt-in CSS variables for extending the design; a reference addition, not already integrated into the approved source.

## Source of truth

Canonical repository: `mmitch2958/absolute-pest-services-nextjs`.

Base: `1989d51`. Approved branch: `codex/homepage-refresh-20260905`.
Design commits: `21fbb27` and `388c416` (final).

The approved source and patch are snapshots, not a complete runnable application. Apply them to the canonical Next.js app, with its existing dependencies and assets. Review differences against the latest code before copying files; preserve newer work. Do not use the historical `SteelCity-ai/AbsolutePestServices.com` repository as the source of truth.

The patch is a developer alternative to the source snapshots. Apply it once only, checking with `git apply --check` first. Do not apply both snapshots and the patch sequentially. No dependencies, credentials, database migrations or environment changes are included.

## Current delivery status

The approved homepage is implemented and locally previewed from the VPS. The broader public-page rollout is specified here, but has not been implemented. The design branch has not been pushed or published. Replit has not been updated by this package. A ZIP upload alone does not change the website; Replit Agent must implement it, validate it and then publish after owner approval.

The homepage reuses the existing live form code and Server Action. The preview uses an isolated dummy database connection; actual lead persistence, email and SMS delivery have not been tested in production.
