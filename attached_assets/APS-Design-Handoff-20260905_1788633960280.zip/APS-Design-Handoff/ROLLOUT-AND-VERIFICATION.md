# Rollout map and integration contract

## Public page families

| Family | Routes / templates | Recommended adaptation |
| --- | --- | --- |
| Homepage | `/` | Apply the approved source exactly; form in hero |
| Service landing pages | `/pest-control`, `/termite-treatment`, `/termites`, `/wildlife-control`, `/wildlife`, `/bed-bug-treatment`, `/bed-bugs`, `/rodents`, `/wasp-removal`, `/bat-removal`, `/carpenter-bee-control`, `/carpenter-bee-treatment`, `/carpenter-bees` | Shared service hero with early existing request form; retain service content, FAQs and SEO |
| Campaign | `/summer-pest-special` | Use the system while preserving valid campaign terms; do not copy stale homepage promotions or invent new offers |
| City/service | `app/[service]/[city]/page.tsx`, `app/city-services/[slug]/page.tsx` | Change shared templates so generated pages inherit the design; preserve content sources, route params and geographic details |
| Service areas | `/service-areas`, `app/service-areas/[slug]/page.tsx` | Preserve the dedicated ServiceAreaForm and its own behavior; bring its presentation into the visual system |
| Company/contact | `/about`, `/contact`, `/request-service` | Matching typography/panels; keep contact and request forms prominent |
| Editorial | `/blog`, `app/blog/[slug]/page.tsx`, `/blog/carpenter-bee-season-pa-de` | Reading-focused article layout, branded cards and contextual service CTA; preserve database-backed content |
| Policy | `/privacy-policy` | Consistent public shell and readable text; preserve policy wording |

This inventory is from commit `388c416`; inspect current routes before rollout and include any newer public pages. Generated city/area pages should inherit template changes rather than become copied static pages.

Operational routes excluded from a full layout redesign: `/admin/**`, `/field/**`, `/invoice/[token]`, payment/customer workflows and APIs. Inspect shared layout effects to keep these operational.

## Preserve existing functionality

The approved homepage form reuses the existing Server Action. `src/components/forms/actions.ts` was unchanged against base `1989d51`. Its field names, required validation and success analytics were preserved.

- Required fields: `name`, `phone`, `email`, `service`, `address`, `city`, `state`, `zip`. Optional: `message`.
- Keep Zod validation and Cloudflare Turnstile verification.
- Keep Neon `contact_submissions` persistence, SendGrid `sendContactFormNotification` and Twilio `sendContactFormSMS`.
- Preserve successful-submission GA4 and Google Ads events; do not count validation failures as conversions.
- Keep existing service defaults and hidden/context values, and preserve specialty/ServiceAreaForm handlers.
- Keep regional phone numbers from the current route's data. The dynamic city/service template currently uses PA `484-643-2225` and DE `302-235-1975`; do not replace all regional values with the header number.
- Preserve URLs, canonical metadata, JSON-LD, redirects, sitemap inclusion, server rendering and dynamic/ISR behavior.
- Do not change environment values, database schema, dependencies or notification destinations as part of styling.

## Recommended implementation sequence

1. Confirm the canonical Next.js app and preserve uncommitted/newer work. Compare the approved snapshots/patch with the current branch.
2. Apply approved homepage, logo and shared shell changes. Verify before extending templates.
3. Introduce reusable public-page styling/components from the design system, scoped so operational pages do not inherit accidental layout changes.
4. Adapt service, geographic and service-area templates, then company/contact, editorial and policy pages. Do not replace page-specific forms merely to achieve visual consistency.
5. Review representative routes and all shared templates, list remaining exceptions and present a preview for owner approval.

## Verification performed on approved homepage

- Next.js 16.2.12 production build passed using Node 24.
- Browser widths 320, 390, 768, 1024 and 1440px had no horizontal overflow and exactly one form inside the homepage hero.
- Desktop, mobile menu, estimate anchors and browser console checked; no console errors in the isolated production preview.
- `/request-service` retained its default form presentation and all eight required fields.
- Empty submission exercised server validation in the isolated preview; no request or notification was created.
- Earlier design revision checked 18 service/area destinations with HTTP 200 responses.
- `git diff --check` passed.

These checks cover the approved homepage and related shared changes, not the future full-site rollout. No production lead persistence, email or SMS delivery was exercised.

## Checks required after wider rollout

Check 320/390/768/1024/1440px, form visibility, label/error readability, menu operation, sticky actions, hash targets, telephone links and no horizontal overflow. Test at least one PA and one DE city page, both geographic template families, a specialty service, a service-area form, request/contact pages, blog list/article and policy page. Verify unchanged operational pages still work.

Exercise invalid input, pending, failure and success states using isolated fixtures or an approved test destination. Confirm exactly one stored request and expected notifications/conversion events per successful submission. An isolated fixture does not establish real inbox delivery; record any production delivery check separately.

Run the project's current build and appropriate checks. Existing baseline limitations at the approved revision:

- Next config ignores TypeScript build errors, so build success is not a clean typecheck.
- Separate TypeScript check reports four pre-existing errors: extra `zip` property in `app/api/admin/test-sms/route.ts`; missing `drizzle-kit` in `drizzle.config.ts`; missing webpack types in `next.config.ts`; unknown `zip` property in `src/lib/email.ts`.
- ESLint 10 fails against the installed React plugin with `contextOrFilename.getFilename is not a function`.

Compare new failures with this baseline; do not silently claim full lint/typecheck success. Build/preview first, then obtain the owner's approval before publishing and verify the deployed site separately.
